package com.java.trabajo.poo.entregable.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoClasico extends Vehiculo {

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }

    public AutoClasico(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio, radio);
    }


    @Override
    public String informarTipo() {
        return "Auto clásico";
    }

    @Override
    public String toString() {
        return "AutoClasico [marca=" + this.getMarca() + ", modelo=" + this.getModelo() + ", color=" + this.getColor() + ", precio=" + this.getPrecio() + ", radio=" + ((this.getRadio() == null) ? "Sin radio" : this.getRadio() ) + "]";
    }

    
}