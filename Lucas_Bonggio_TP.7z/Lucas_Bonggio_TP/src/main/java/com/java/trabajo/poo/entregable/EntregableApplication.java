package com.java.trabajo.poo.entregable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntregableApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntregableApplication.class, args);
	}

}
