package com.java.trabajo.poo.entregable.entidades;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
// Defino la clase como abstracta para impedir las instancias directas. 
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private double  precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, double precio, Radio radio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = radio;
    }

    public Vehiculo(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public Vehiculo(String marca, String modelo, String color, Radio radio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = radio;
    }

    public Vehiculo(String marca, String modelo, String color, double precio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    /**
     * Método para agregar una radio a un vehículo. 
     * Primero verifica si la radio es nula, si es nula, nos devuelve un mensaje.
     * Si no es nula, verifica si la radio está en otra vehículo.
     * Si está libre, y el vehículo no tiene una radio, la asigna correctamente.
     * Si la radio está en ocupada o si el vehículo tiene una radio, nos responde de otra manera. 
     * @param nuevaRadio Es la radio que se va a agregar. 
     */
    public void agregarRadio(Radio nuevaRadio) {
        if(nuevaRadio == null){
            System.out.println("No se puede agregar una radio nula. ");
        }else{
            if(nuevaRadio.getVehiculo() == null){
                if(this.radio == null){
                    this.radio = nuevaRadio;
                    nuevaRadio.setVehiculo(this);
                    System.out.println("Radio agregada correctamente. ");
                    }else{
                        System.out.println("El vehículo ya posee una radio. ");
                }
            }else{
                System.out.println("La radio está en un vehículo. ");
            }
        }
    }

    /**
     * El método es cambiar la radio del vehículo.
     * Verifica si la radio es nula y que no este en un Auto nuevo.
     * Despues hace otra verificación para saber si el auto tiene radio y si es el caso, la quita, seteandola en null.
     * Finalmente añade la radio al nuevo vehículo.
     * @param nuevaRadio Es la radio que se va a agregar. 
     */
    public void cambiarRadio(Radio nuevaRadio) {
        if (nuevaRadio == null) {
            System.out.println("La radio no puede ser nula.");
            return;
        }
    
        if (!verificarRadio(nuevaRadio)) {
            System.out.println("Al Auto nuevo no puede quitarle la radio.");
            return;
        }
    
        if (this.radio != null) {
            this.radio.setVehiculo(null);
            System.out.println("Quitando radio actual del vehículo...");
        }
    
        if (nuevaRadio.getVehiculo() != null && nuevaRadio.getVehiculo() != this) {
            nuevaRadio.getVehiculo().radio = null;  // quitamos desde el otro vehículo
            System.out.println("La radio se quitó del vehículo en el que estaba.");
        }
    
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculo(this);
        System.out.println("Radio cambiada correctamente.");
    }

    /**
     * Verifica si la radio está en un Auto nuevo. 
     * Primero comprueba si la radio tiene un vehículo, si lo tiene, lo asignamos a una variable del tipo Vehiculo, su clase padre.
     * Despues chequeamos con el método informarTipo() de que tipo es el vehículo asignado.
     * Si la radio no tiene un vehículo asignado, directamente devuelve true. 
     * @param nuevaRadio La radio que se va a verificar.
     * @return Devuelve true si la radio está en un tipo de auto que no sea Auto nuevo.
     */
    public boolean verificarRadio(Radio nuevaRadio){
        if(nuevaRadio.getVehiculo() != null){
            Vehiculo tipoAuto = nuevaRadio.getVehiculo();
            if(tipoAuto.informarTipo().equals("Auto nuevo")){
                return false;
            }else{
                return true;
            }
        }else{
            return true;
        }
    }

    /**
     * Este método nos informa de que tipo es el vehículo que lo utilice.
     * Cada vehículo sobreescribe, colocando un mensaje dependiende cual sea el vehículo, el método.
     */
    public abstract String informarTipo();

}
