package com.java.trabajo.poo.entregable.tests;

import com.java.trabajo.poo.entregable.entidades.AutoClasico;
import com.java.trabajo.poo.entregable.entidades.AutoNuevo;
import com.java.trabajo.poo.entregable.entidades.Radio;

public class testTrabajo {
    public static void main(String[] args) {
        

        AutoClasico autoClasico1 = new AutoClasico("TOYOTA", "COROLLA", "VCERDE");
        System.out.println(autoClasico1);
        autoClasico1.agregarRadio(new Radio("Pioneer", 10));

        AutoClasico autoClasico3 = new AutoClasico("Ford", "Escort", "Bordo", 510000, null);

        Radio radioAuto = new Radio("lg", 10);

        AutoNuevo autonuevo00 = new AutoNuevo("Peugeot", "205","Verde", radioAuto);

        Radio radioCmabi = new Radio("LG", 2F);
        autonuevo00.cambiarRadio(radioCmabi);

        System.out.println(autoClasico1);

        autoClasico3.agregarRadio(null);
        
        autoClasico1.cambiarRadio(radioCmabi);
        System.out.println(autoClasico3);

    }
}
