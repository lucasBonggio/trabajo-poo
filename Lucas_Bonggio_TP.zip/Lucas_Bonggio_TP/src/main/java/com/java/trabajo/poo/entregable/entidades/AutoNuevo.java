package com.java.trabajo.poo.entregable.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String marca, String modelo, String color, Double precio, Radio radio){
        super(marca, modelo, color, precio, radio);
    }

    public AutoNuevo(String marca, String modelo, String color, Radio radio){
        super(marca, modelo, color, radio);
    }

    @Override
    public String informarTipo() {
        return "Auto nuevo";
    }
    
    

}