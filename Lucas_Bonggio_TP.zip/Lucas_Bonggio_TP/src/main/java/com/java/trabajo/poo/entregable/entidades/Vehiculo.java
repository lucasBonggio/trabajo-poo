package com.java.trabajo.poo.entregable.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
// Defino la clase como abstracta para impedir las instancias directas. 
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private double  precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, double precio, Radio radio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        agregarRadio(radio);
    }

    public Vehiculo(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public Vehiculo(String marca, String modelo, String color, Radio radio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        agregarRadio(radio);
    }

    public Vehiculo(String marca, String modelo, String color, double precio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    /**
     * Método para agregar una radio a un vehículo. 
     * Verifica si la radio posee un vehículo y si el vehículo donde se quiere añadir, no tenga una radio.
     * Nos devuelve un mensaje dependiendo la respuesta.
     * @param nuevaRadio Es la radio que se va a agregar. 
     */
    public void agregarRadio(Radio nuevaRadio) {
        if(nuevaRadio == null){
            System.out.println("No se puede agregar una radio nula. ");
        }else{
            if(nuevaRadio.getVehiculo() == null){
                if(this.radio == null){
                    this.radio = nuevaRadio;
                    nuevaRadio.setVehiculo(this);
                    System.out.println("Radio agregada correctamente. ");
                    }else{
                        System.out.println("El vehículo ya posee una radio. ");
                }
            }else{
                System.out.println("La radio está en un vehículo. ");
            }
        }
    }

    /**
     * El método es cambiar la radio del vehículo.
     * Verifica que si el vehículo posee una radio y si es el caso, la agrega; si el vehículo tiene una radio, lo que hace es sacar la antigua radio y colocar la nueva. 
     * @param nuevaRadio Es la radio que se va a agregar. 
     */
    public void cambiarRadio(Radio nuevaRadio) {
        if(this.radio != null){
            this.radio.setVehiculo(null);
            System.out.println("Quitando radio actual del vehículo...");
        } 

        if(nuevaRadio.getVehiculo() != null && nuevaRadio.getVehiculo() != this){
            this.radio.setVehiculo(null);
            this.radio = null;
            System.out.println("La radio se quitó del vehículo en el que estaba. ");
        }
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculo(this);
        System.out.println("Radio cambiada correctamente. ");
    }

    /**
     * Este método nos informa de que tipo es el vehículo que lo utilice.
     * Cada vehículo sobreescribe, colocando un mensaje dependiende cual sea el vehículo, el método.
     */
    public abstract void informarTipo();

}
