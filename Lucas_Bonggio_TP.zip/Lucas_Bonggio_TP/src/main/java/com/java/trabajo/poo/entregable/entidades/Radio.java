package com.java.trabajo.poo.entregable.entidades;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Radio {

    private String marca;
    private float potencia;
    private Vehiculo vehiculo = null;

    public Radio(String marca, float potencia){
        this.marca = marca;
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }

}
