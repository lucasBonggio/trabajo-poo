package com.java.trabajo.poo.entregable.tests;

import com.java.trabajo.poo.entregable.entidades.AutoClasico;
import com.java.trabajo.poo.entregable.entidades.AutoNuevo;
import com.java.trabajo.poo.entregable.entidades.Colectivo;
import com.java.trabajo.poo.entregable.entidades.Radio;

public class testTrabajo {
    public static void main(String[] args) {
        
        Radio radio1 = new Radio("TCL", 1);

        AutoClasico autoClasico1 = new AutoClasico("TOYOTA", "COROLLA", "VCERDE");
        System.out.println(autoClasico1);
        autoClasico1.agregarRadio(new Radio("Pioneer", 10));

        AutoClasico autoClasico23 = new AutoClasico("pedro", "pedro", "pedro");
        AutoClasico autoClasico3 = new AutoClasico("verde", "amarillo", "rojo", 10, null);


        


        System.out.println(autoClasico1);

        autoClasico3.agregarRadio(null);
        
        autoClasico1.cambiarRadio(radio1);
        System.out.println(autoClasico3);

        // //  Un Auto Clásico se puede fabricar sin Radio, después se puede agregar una Radio.
        // AutoClasico autoClasico1 = new AutoClasico("Ford", "F100", "Roja");
        // autoClasico1.agregarRadio(new Radio("TCL", 10));

        // //  - Un Auto Nuevo siempre tiene Radio y se puede cambiar de Radio. 
        // AutoNuevo autoNuevo1 = new AutoNuevo("Ford", "Focus", "Gris", 20000000.0, new Radio("Pioneer", 20));    
        // autoNuevo1.agregarRadio(new Radio("Sony", 20));
        // //  - Una Radio solo puede estar en un Vehículo a la vez. 
        // Radio radio1 = new Radio("Pioneer", 30);
        
        // AutoNuevo autoNuevo3 = new AutoNuevo("Ford", "Fiesta", "Gris", radio1);
        
        // AutoNuevo autoNuevo4 = new AutoNuevo("Ford", "Fiesta", "Azul", radio1);

        // //  - Un Vehículo siempre tiene color marca modelo. 
        // //  - Un Vehículo no siempre tiene precio. 

        // AutoClasico autoClasico5 = new AutoClasico("Renault", "12", "Celeste");
        // //  - Una Radio siempre tiene marca, potencia. 

        // //  - Los Colectivos se pueden fabricar sin radio y después se puede agregar una radio. 
        // Colectivo colectivo1 = new Colectivo("Mercedez-Benz", "98", "Verde y amarillo");
        // colectivo1.agregarRadio(new Radio("Sony", 15));

        // //  - Todos los vehículos pueden cambiar de radio. 
        // autoClasico1.cambiarRadio(new Radio("JBL", 20));
        // autoNuevo1.cambiarRadio(new Radio("Phillip", 10));
        // colectivo1.cambiarRadio(new Radio("LG", 20)); 

        // //  - En todos los vehículos se puede agregar una Radio. 
        // AutoClasico autoClasico0 = new AutoClasico("Peugeot", "504", "Beige");

        // AutoNuevo autoNuevo0 = new AutoNuevo("Volkswagen", "Vento","Gris", null);

        // Colectivo colectivo0 = new Colectivo("Mercedes-Benz", "98 5", "Verde y amarillo", 200000.0);

        // autoClasico0.agregarRadio(new Radio("Acme", 20));
        // autoNuevo0.agregarRadio(new Radio("Lenovo", 10));

        // System.out.println(autoClasico0);
        // colectivo0.agregarRadio(new Radio("Hp", 10));

        // Radio radio3 = new Radio("RCA", 0);
        // System.out.println(radio3);
        // Radio radio2 = new Radio("Genius", 5);
        // System.out.println(radio2);
        // //  - No se pueden crear subproductos derivados del Colectivo. 
        // //  - No existen instancias puras de Vehículo. 
        // //  - Cada Vehículo debe poder informar qué tipo de vehículo 
        // autoClasico0.informarTipo();
        // autoNuevo0.informarTipo();
        // colectivo0.informarTipo();

    }
}
