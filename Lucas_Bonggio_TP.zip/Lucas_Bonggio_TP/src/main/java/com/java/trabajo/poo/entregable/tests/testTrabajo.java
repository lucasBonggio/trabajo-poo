package com.java.trabajo.poo.entregable.tests;

import com.java.trabajo.poo.entregable.entidades.AutoClasico;
import com.java.trabajo.poo.entregable.entidades.AutoNuevo;
import com.java.trabajo.poo.entregable.entidades.Colectivo;
import com.java.trabajo.poo.entregable.entidades.Radio;

public class testTrabajo {
    public static void main(String[] args) {

        AutoClasico autoClasico200 = new AutoClasico("Toyota", "Corolla", "Negro", new Radio("xd", 1f));

        Radio radioPrueba = new Radio("SONY", 20f);
        Radio radioPrueba1 = new Radio("LG", 15f);

        
        autoClasico200.cambiarRadio(radioPrueba);

        AutoNuevo autoNuevo123 = new AutoNuevo("Ford", "Focus", "Azul", radioPrueba1);

        System.out.println(autoNuevo123);

        Colectivo colectivo1 = new Colectivo("Mercedes-Benz", "98", "Amarillo", radioPrueba1);
        // AutoNuevo autoNuevo321 = new AutoNuevo("Chevrolet", "Astra", "Gris", radioPrueba1);
        // AutoClasico autoClasico321 = new AutoClasico("Ford", "Taunus","Naranja",radioPrueba1);


        System.out.println(colectivo1);
    }
}
