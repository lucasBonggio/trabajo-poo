package com.java.trabajo.poo.entregable.entidades;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper=true)
// Declaro la clase del tipo "final" para que no se pueda crear objetos del mismo.
public final class Colectivo extends Vehiculo {

    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public Colectivo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color, radio);
    }

    public Colectivo(String marca, String modelo, String color, Double precio, Radio radio) {
        super(marca, modelo, color, precio);
        super.agregarRadio(radio);
    }
    
    @Override
    public String informarTipo() {
        return "Colectivo";
        
    }
}
