package com.java.trabajo.poo.entregable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntregableApplicationTests {

	@Test
	void contextLoads() {
	}

}
